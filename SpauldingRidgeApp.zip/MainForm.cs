
using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace SpauldingRidgeApp
{
    public partial class MainForm : Form
    {
        private SQLiteConnection sqliteConn;

        public MainForm()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData(string filter = "")
        {
            using (sqliteConn = new SQLiteConnection("Data Source=SpauldingRidge.db;Version=3;"))
            {
                sqliteConn.Open();
                string query = "SELECT * FROM Employees";
                if (!string.IsNullOrWhiteSpace(filter))
                {
                    query += " WHERE Name LIKE @filter OR Role LIKE @filter OR Location LIKE @filter";
                }

                using (SQLiteCommand cmd = new SQLiteCommand(query, sqliteConn))
                {
                    if (!string.IsNullOrWhiteSpace(filter))
                        cmd.Parameters.AddWithValue("@filter", "%" + filter + "%");

                    SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            string filter = searchTextBox.Text.Trim();
            LoadData(filter);
        }
    }
}
