using System;
using System.Windows.Forms;

namespace SpauldingRidgeApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
    }
}
