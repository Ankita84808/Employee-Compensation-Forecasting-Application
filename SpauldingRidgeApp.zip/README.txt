# Spaulding Ridge Case Study App

## How to Run
1. Open `SpauldingRidgeApp.sln` in Visual Studio 2022 or later.
2. Ensure SQLite NuGet package is installed (System.Data.SQLite).
3. Build and run the application.

## Features
- Employee list
- Ratings and compensation viewer
- Industry comparison

## Included Files
- `SpauldingRidge_DB.sql`: SQL script to build and seed the database
- `SpauldingRidge.db`: Prebuilt SQLite DB (coming soon)
